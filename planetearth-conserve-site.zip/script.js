const toggleMusic = document.getElementById("toggle-music");
const music = document.getElementById("background-music");

toggleMusic.addEventListener("click", () => {
  if (music.paused) {
    music.play();
    toggleMusic.textContent = "Pause Music";
  } else {
    music.pause();
    toggleMusic.textContent = "Play Music";
  }
});
